// Ping Pang Paris — mobile app prototype
// 3 screens (Home / Train / Matches), bottom nav routing.

const { useState, useMemo, useEffect, useRef, createContext, useContext } = React;

// ─── viewport / responsive ────────────────────────────
function useViewport() {
  const [vw, setVw] = useState(typeof window !== 'undefined' ? window.innerWidth : 1024);
  useEffect(() => {
    const onR = () => setVw(window.innerWidth);
    window.addEventListener('resize', onR);
    return () => window.removeEventListener('resize', onR);
  }, []);
  return { vw, isMobile: vw < 640 };
}

// ─── toast / sheet context ────────────────────────────
const UICtx = createContext(null);
const useUI = () => useContext(UICtx);

function UIProvider({ children, isMobile }) {
  const [toast, setToast] = useState(null);
  const [sheet, setSheet] = useState(null); // { title, body }
  const [drawer, setDrawer] = useState(false);
  const tRef = useRef(0);

  const showToast = (msg) => {
    setToast(msg);
    clearTimeout(tRef.current);
    tRef.current = setTimeout(() => setToast(null), 1800);
  };
  const openSheet = (s) => setSheet(s);
  const closeSheet = () => setSheet(null);

  return (
    <UICtx.Provider value={{ showToast, openSheet, closeSheet, drawer, setDrawer, isMobile }}>
      {children}
      <ToastLayer toast={toast} />
      <Sheet sheet={sheet} onClose={closeSheet} />
      <Drawer open={drawer} onClose={() => setDrawer(false)} />
    </UICtx.Provider>
  );
}

function ToastLayer({ toast }) {
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 100, zIndex: 100,
      display: 'flex', justifyContent: 'center', pointerEvents: 'none',
    }}>
      <div style={{
        opacity: toast ? 1 : 0, transform: `translateY(${toast ? 0 : 8}px)`,
        transition: 'all .25s ease',
        padding: '12px 20px', borderRadius: 999,
        background: 'rgba(8,22,17,0.92)', color: '#F2F7F2',
        border: '1px solid rgba(184,220,197,0.32)',
        fontFamily: '"Inter", system-ui, sans-serif', fontWeight: 600,
        fontSize: 13, letterSpacing: '0.06em',
        boxShadow: '0 12px 32px rgba(0,0,0,0.45)',
        maxWidth: '85%', textAlign: 'center',
      }}>{toast}</div>
    </div>
  );
}

function Sheet({ sheet, onClose }) {
  const open = !!sheet;
  return (
    <div onClick={onClose} style={{
      position: 'absolute', inset: 0, zIndex: 90,
      pointerEvents: open ? 'auto' : 'none',
      background: open ? 'rgba(0,0,0,0.55)' : 'transparent',
      transition: 'background .25s ease',
      display: 'flex', alignItems: 'flex-end',
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: '100%', maxHeight: '78%', overflow: 'auto',
        background: '#143226', borderTopLeftRadius: 26, borderTopRightRadius: 26,
        borderTop: '1px solid rgba(184,220,197,0.22)',
        transform: `translateY(${open ? 0 : 100}%)`,
        transition: 'transform .3s cubic-bezier(.2,.8,.2,1)',
        padding: '14px 22px 110px',
        color: '#F2F7F2',
      }}>
        <div style={{ width: 44, height: 4, borderRadius: 99, background: 'rgba(242,247,242,0.25)', margin: '4px auto 18px' }} />
        {sheet && (
          <>
            <div style={{ fontFamily: '"Big Shoulders Stencil Display", Impact, sans-serif', fontWeight: 800, fontSize: 28, letterSpacing: '0.02em', marginBottom: 10 }}>{sheet.title}</div>
            {sheet.body}
            <button onClick={onClose} style={{
              marginTop: 24, width: '100%', padding: '14px 20px', borderRadius: 12,
              background: 'transparent', border: '1px solid rgba(184,220,197,0.32)',
              color: '#EFE5C8', fontFamily: '"Inter", system-ui, sans-serif',
              fontWeight: 700, fontSize: 12, letterSpacing: '0.18em', cursor: 'pointer',
            }}>CLOSE</button>
          </>
        )}
      </div>
    </div>
  );
}

function Drawer({ open, onClose }) {
  const items = ['Profile','Achievements','Equipment','Coaching','Subscriptions','Settings','Sign out'];
  return (
    <div onClick={onClose} style={{
      position: 'absolute', inset: 0, zIndex: 95,
      pointerEvents: open ? 'auto' : 'none',
      background: open ? 'rgba(0,0,0,0.55)' : 'transparent',
      transition: 'background .25s ease',
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        position: 'absolute', top: 0, bottom: 0, left: 0, width: 280,
        background: '#0E2820', borderRight: '1px solid rgba(184,220,197,0.18)',
        transform: `translateX(${open ? 0 : -100}%)`,
        transition: 'transform .3s cubic-bezier(.2,.8,.2,1)',
        padding: '70px 22px 30px', color: '#F2F7F2',
        display: 'flex', flexDirection: 'column', gap: 4,
      }}>
        <div style={{ fontFamily: '"Big Shoulders Stencil Display", Impact, sans-serif', fontWeight: 800, fontSize: 24, letterSpacing: '0.04em', color: '#B8DCC5', marginBottom: 20 }}>MENU</div>
        {items.map(it => (
          <button key={it} onClick={onClose} style={{
            textAlign: 'left', padding: '14px 4px',
            background: 'none', border: 'none', cursor: 'pointer',
            borderBottom: '1px solid rgba(184,220,197,0.10)',
            color: '#F2F7F2', fontFamily: '"Inter", system-ui, sans-serif',
            fontWeight: 600, fontSize: 14, letterSpacing: '0.04em',
          }}>{it}</button>
        ))}
      </div>
    </div>
  );
}

// ─── palette ──────────────────────────────────────────
const C = {
  bg:        '#0C211A',
  bgGrad:    'radial-gradient(140% 80% at 50% 0%, #143329 0%, #0B1E17 65%)',
  card:      '#143226',
  cardHi:    '#193E2F',
  border:    'rgba(184,220,197,0.10)',
  borderHi:  'rgba(184,220,197,0.22)',
  ink:       '#F2F7F2',
  inkDim:    'rgba(242,247,242,0.62)',
  inkFaint:  'rgba(242,247,242,0.40)',
  mint:      '#B8DCC5',
  mintDeep:  '#9BC9AE',
  cream:     '#EFE5C8',
  warm:      '#E8C99B',
  loss:      '#E89B8B',
};

const fontDisplay  = '"Big Shoulders Stencil Display", "Big Shoulders Display", "Saira Condensed", Impact, sans-serif';
const fontSans     = '"Inter", -apple-system, system-ui, sans-serif';
const fontItalic   = '"Cormorant Garamond", "EB Garamond", Georgia, serif';

// ─── tiny icon set (line, currentColor) ───────────────
const Icon = {
  menu:     (s=22) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 7h18M3 12h18M3 17h18"/></svg>,
  user:     (s=22) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="10" r="3.2"/><path d="M5.5 19c1.5-3 4-4.2 6.5-4.2S17 16 18.5 19"/></svg>,
  home:     (s=22) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"><path d="M12 4l-8 6.5V20h5v-5.5h6V20h5v-9.5L12 4z"/></svg>,
  brain:    (s=22) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M9 4.5C7 4.5 5.5 6 5.5 8c-1.5.5-2.5 2-2.5 3.7 0 1.4.7 2.6 1.8 3.3-.2.5-.3 1-.3 1.5 0 2 1.5 3.5 3.5 3.5.7 0 1.3-.2 1.9-.5"/><path d="M15 4.5c2 0 3.5 1.5 3.5 3.5 1.5.5 2.5 2 2.5 3.7 0 1.4-.7 2.6-1.8 3.3.2.5.3 1 .3 1.5 0 2-1.5 3.5-3.5 3.5-.7 0-1.3-.2-1.9-.5"/><path d="M12 5v15"/></svg>,
  map:      (s=22) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"><path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2z"/><path d="M9 4v14M15 6v14"/></svg>,
  trophy:   (s=22) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round"><path d="M7 4h10v4a5 5 0 0 1-10 0V4z"/><path d="M7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3"/><path d="M9 20h6M12 13v7"/></svg>,
  bag:      (s=22) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"><path d="M5 8h14l-1.2 12H6.2L5 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg>,
  calendar: (s=22) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3.5" y="5" width="17" height="15.5" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>,
  clock:    (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2.5" strokeLinecap="round"/></svg>,
  history:  (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 8v4l3 2"/></svg>,
  bolt:     (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"><path d="M13 3 5 14h6l-1 7 8-11h-6l1-7z"/></svg>,
  pin:      (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M12 21s7-6.5 7-12a7 7 0 1 0-14 0c0 5.5 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/></svg>,
  filter:   (s=22) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M4 7h16M7 12h10M10 17h4"/></svg>,
  check:    (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12.5 10 18l10-12"/></svg>,
  arrowR:   (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>,
  plus:     (s=22) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>,
  verify:   (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill={C.mint}><path d="M12 1.5l2.4 1.9 3 .2 1.1 2.8 2.6 1.6-.5 3 .9 2.9-2.1 2.2-.8 2.9-3 .5-2.2 2.1-2.9-.9-2.9.9-2.2-2.1-3-.5-.8-2.9L1.5 14l.9-2.9-.5-3 2.6-1.6 1.1-2.8 3-.2L12 1.5z"/><path d="M8 12.2l2.8 2.8L16 9.5" stroke={C.bg} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"/></svg>,
  trend:    (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round"><path d="M3 17l6-6 4 4 8-9"/><path d="M14 6h7v7"/></svg>,
};

// ─── shared blocks ────────────────────────────────────
function TopBar() {
  const { setDrawer, openSheet } = useUI();
  return (
    <div style={{
      height: 64, padding: '0 22px', display: 'flex', alignItems: 'center',
      justifyContent: 'space-between',
      borderBottom: `1px solid ${C.border}`,
      background: 'rgba(8,22,17,0.55)',
      backdropFilter: 'blur(8px)',
      position: 'sticky', top: 0, zIndex: 5,
      color: C.ink,
    }}>
      <button onClick={() => setDrawer(true)} style={iconBtn}>{Icon.menu(24)}</button>
      <div style={{
        fontFamily: fontDisplay, fontWeight: 800, letterSpacing: '0.05em',
        fontSize: 18, color: C.ink, whiteSpace: 'nowrap',
      }}>PING PANG PARIS</div>
      <button onClick={() => openSheet({
        title: 'EUGENIA SOREL',
        body: <ProfileSheet />,
      })} style={iconBtn}>{Icon.user(26)}</button>
    </div>
  );
}

function ProfileSheet() {
  const fields = [
    ['Member since', 'March 2023'],
    ['Club', 'Le Marais Ping'],
    ['Style', 'Attacker'],
    ['Rubbers', 'Hurricane 3 / Tenergy 05'],
    ['Blade', 'Viscaria FL'],
    ['Region', 'Paris — 11e'],
  ];
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 18 }}>
        <div style={{
          width: 60, height: 60, borderRadius: 99, flexShrink: 0,
          background: 'radial-gradient(60% 60% at 35% 30%, #d6b890 0%, #6b4a2e 60%, #1c100a 100%)',
          border: `1.5px solid ${C.borderHi}`,
        }} />
        <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 4 }}>
          <div style={{ fontFamily: fontSans, fontWeight: 700, fontSize: 14, color: C.ink, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>1450 ELO · #24 PARIS</div>
          <div style={{ fontFamily: fontSans, fontSize: 13, color: C.inkDim }}>Streak: 5 days</div>
        </div>
      </div>
      {fields.map(([k,v]) => (
        <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: `1px solid ${C.border}` }}>
          <span style={{ ...kicker }}>{k.toUpperCase()}</span>
          <span style={{ fontFamily: fontSans, fontSize: 14, color: C.ink, fontWeight: 600 }}>{v}</span>
        </div>
      ))}
    </div>
  );
}

const iconBtn = {
  background: 'none', border: 'none', color: C.ink, padding: 4,
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  cursor: 'pointer',
};

function BottomNav({ tab, onTab }) {
  const items = [
    { id: 'home',    label: 'HOME',    icon: Icon.home },
    { id: 'train',   label: 'TRAIN',   icon: Icon.brain },
    { id: 'finder',  label: 'FINDER',  icon: Icon.map },
    { id: 'matches', label: 'MATCHES', icon: Icon.trophy },
    { id: 'merch',   label: 'MERCH',   icon: Icon.bag },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      paddingBottom: 28, paddingTop: 10,
      background: 'linear-gradient(to top, #081610 70%, rgba(8,22,17,0.0))',
      display: 'flex', justifyContent: 'space-around',
      borderTop: `1px solid ${C.border}`,
      zIndex: 4,
    }}>
      {items.map(it => {
        const active = tab === it.id;
        return (
          <button key={it.id} onClick={() => onTab(it.id)} style={{
            background: 'none', border: 'none', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            gap: 4, padding: '6px 10px 4px', borderRadius: 10,
            color: active ? C.cream : 'rgba(242,247,242,0.78)',
            position: 'relative',
          }}>
            {active && <div style={{
              position: 'absolute', inset: '-2px 0', borderRadius: 14,
              background: 'rgba(239,229,200,0.07)',
              border: `1px solid rgba(239,229,200,0.22)`,
              zIndex: -1,
            }} />}
            {it.icon(22)}
            <span style={{
              fontFamily: fontSans, fontSize: 10, letterSpacing: '0.10em',
              fontWeight: 600,
            }}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function Card({ children, style }) {
  return (
    <div style={{
      background: `linear-gradient(180deg, ${C.cardHi} 0%, ${C.card} 100%)`,
      border: `1px solid ${C.border}`,
      borderRadius: 22,
      padding: 22,
      ...style,
    }}>{children}</div>
  );
}

// ─── HOME ─────────────────────────────────────────────
function HomeScreen({ onNav }) {
  const { showToast, openSheet } = useUI();
  return (
    <div style={{ padding: '20px 18px 130px', display: 'flex', flexDirection: 'column', gap: 18 }}>
      {/* Active player */}
      <button onClick={() => openSheet({ title: 'EUGENIA SOREL', body: <ProfileSheet /> })}
        style={{ all: 'unset', cursor: 'pointer', display: 'block' }}>
      <Card style={{ padding: '24px 24px 26px' }}>
        <div style={kicker}>ACTIVE PLAYER</div>
        <div style={{
          fontFamily: fontDisplay, fontWeight: 800, fontSize: 66, lineHeight: 0.95,
          color: C.mint, letterSpacing: '0.01em', marginTop: 6, marginBottom: 22,
        }}>EUGENIA</div>

        <StatRow label="ELO RATING" value="1450 (Glicko-2)" />
        <div style={{ height: 1, background: C.border, margin: '14px 0' }} />
        <StatRow label="GLOBAL RANK" value="#24 PARIS" valueFont={fontDisplay} />

        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          marginTop: 18,
          padding: '8px 16px', borderRadius: 999,
          background: 'rgba(239,229,200,0.12)',
          border: `1px solid rgba(239,229,200,0.32)`,
          color: C.cream,
          fontFamily: fontSans, fontWeight: 700, fontSize: 12, letterSpacing: '0.10em',
        }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: C.cream }} />
          STREAK: 5 DAYS
        </div>
      </Card>
      </button>

      {/* Quote + CTA */}
      <div style={{
        position: 'relative', borderRadius: 22, overflow: 'hidden',
        border: `1px solid ${C.border}`,
        background: C.card,
      }}>
        {/* paddle backdrop */}
        <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
          <PaddleSVG />
          <div style={{
            position: 'absolute', inset: 0,
            background: 'radial-gradient(60% 50% at 50% 35%, rgba(184,220,197,0.10) 0%, rgba(20,50,38,0) 70%), linear-gradient(180deg, rgba(20,50,38,0) 40%, rgba(20,50,38,0.85) 90%)',
          }} />
        </div>
        <div style={{ position: 'relative', padding: '26px 24px 24px' }}>
          <div style={{
            fontFamily: fontItalic, fontStyle: 'italic',
            fontSize: 21, lineHeight: 1.25, color: C.ink,
            textWrap: 'pretty',
          }}>
            "Precision is not an accident. It is the result of high-intent training."
          </div>
          <div style={{ height: 130 }} />
          <button onClick={() => onNav('train')} style={{
            width: '100%', padding: '18px 20px', borderRadius: 16,
            background: C.mint, border: 'none',
            color: '#0C211A',
            fontFamily: fontSans, fontWeight: 700, fontSize: 14,
            letterSpacing: '0.18em', cursor: 'pointer',
            boxShadow: '0 0 32px rgba(184,220,197,0.35), 0 10px 30px rgba(0,0,0,0.3)',
          }}>QUICK START TRAINING</button>
        </div>
      </div>

      {/* Last match + Daily goal */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <button onClick={() => onNav('matches')} style={{ all: 'unset', cursor: 'pointer' }}>
        <Card style={{ padding: 18 }}>
          <div style={kicker}>LAST MATCH</div>
          <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 8, color: C.ink, fontFamily: fontSans, fontWeight: 700, fontSize: 18 }}>
            <span style={{ color: C.mint }}>{Icon.history(16)}</span> 3-0 WIN
          </div>
          <div style={{ marginTop: 6, color: C.inkDim, fontFamily: fontSans, fontSize: 13 }}>vs. Marc-Andre</div>
        </Card>
        </button>
        <button onClick={() => showToast('Daily goal: 75% — keep going!')} style={{ all: 'unset', cursor: 'pointer' }}>
        <Card style={{ padding: 18 }}>
          <div style={kicker}>DAILY GOAL</div>
          <div style={{ height: 6, background: 'rgba(184,220,197,0.18)', borderRadius: 99, marginTop: 18, overflow: 'hidden' }}>
            <div style={{ width: '75%', height: '100%', background: `linear-gradient(90deg, ${C.mintDeep}, ${C.mint})`, borderRadius: 99 }} />
          </div>
          <div style={{ marginTop: 10, color: C.ink, fontFamily: fontSans, fontWeight: 700, fontSize: 14, letterSpacing: '0.06em' }}>75% COMPLETE</div>
        </Card>
        </button>
      </div>

      {/* Next session */}
      <button onClick={() => openSheet({ title: 'NEXT CLUB SESSION', body: <SessionSheet /> })}
        style={{ all: 'unset', cursor: 'pointer', display: 'block' }}>
      <Card style={{ padding: 18 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ textAlign: 'left' }}>
            <div style={kicker}>NEXT CLUB SESSION</div>
            <div style={{ marginTop: 8, color: C.ink, fontFamily: fontSans, fontWeight: 700, fontSize: 16, letterSpacing: '0.04em' }}>LE MARAIS PING</div>
            <div style={{ color: C.inkDim, fontFamily: fontSans, fontSize: 13, marginTop: 2 }}>Tomorrow, 18:30</div>
          </div>
          <div style={{ color: C.inkDim }}>{Icon.calendar(26)}</div>
        </div>
      </Card>
      </button>

      {/* Training volume */}
      <button onClick={() => showToast('Training volume: 12.4h this week (+1.2h)')}
        style={{ all: 'unset', cursor: 'pointer', display: 'block' }}>
      <Card style={{ padding: 18 }}>
        <div style={kicker}>TRAINING VOLUME</div>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 6 }}>
          <div style={{
            fontFamily: fontDisplay, fontWeight: 800, fontSize: 46,
            color: C.ink, letterSpacing: '0.01em', lineHeight: 1,
          }}>12.4H</div>
          <div style={{ color: C.cream, fontFamily: fontSans, fontWeight: 700, fontSize: 12, letterSpacing: '0.14em' }}>THIS WEEK</div>
        </div>
      </Card>
      </button>
    </div>
  );
}

function SessionSheet() {
  const { showToast, closeSheet } = useUI();
  return (
    <div style={{ fontFamily: fontSans, color: C.ink }}>
      <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 4 }}>LE MARAIS PING</div>
      <div style={{ color: C.inkDim, fontSize: 13, marginBottom: 16 }}>Tomorrow • 18:30 – 20:30</div>
      {[
        ['Coach','Vincent M.'],
        ['Tables','2 reserved'],
        ['Partners','Marc-Andre, Sofia'],
        ['Focus','Backhand counter-loop'],
      ].map(([k,v]) => (
        <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: `1px solid ${C.border}` }}>
          <span style={{ ...kicker }}>{k.toUpperCase()}</span>
          <span style={{ fontSize: 14, color: C.ink, fontWeight: 600 }}>{v}</span>
        </div>
      ))}
      <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
        <button onClick={() => { closeSheet(); showToast('Session confirmed ✓'); }} style={btnPrimary}>CONFIRM</button>
        <button onClick={() => { closeSheet(); showToast('Reschedule sent to club'); }} style={btnGhost}>RESCHEDULE</button>
      </div>
    </div>
  );
}

const btnPrimary = {
  flex: 1, padding: '13px', borderRadius: 12, border: 'none',
  background: C.mint, color: '#0C211A',
  fontFamily: fontSans, fontWeight: 700, fontSize: 12, letterSpacing: '0.16em',
  cursor: 'pointer',
};
const btnGhost = {
  flex: 1, padding: '13px', borderRadius: 12,
  background: 'transparent', border: `1px solid ${C.borderHi}`,
  color: C.cream,
  fontFamily: fontSans, fontWeight: 700, fontSize: 12, letterSpacing: '0.16em',
  cursor: 'pointer',
};

const kicker = {
  fontFamily: fontSans, fontSize: 11.5, fontWeight: 700,
  letterSpacing: '0.18em', color: 'rgba(242,247,242,0.78)',
};

function StatRow({ label, value, valueFont = fontSans }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
      <div style={{ ...kicker }}>{label}</div>
      <div style={{
        fontFamily: valueFont, fontWeight: valueFont === fontDisplay ? 800 : 700,
        fontSize: valueFont === fontDisplay ? 24 : 22,
        color: C.ink, letterSpacing: valueFont === fontDisplay ? '0.02em' : '0',
      }}>{value}</div>
    </div>
  );
}

function PaddleSVG() {
  return (
    <svg width="100%" height="280" viewBox="0 0 360 280" preserveAspectRatio="xMidYMid slice" style={{ display: 'block', position: 'absolute', inset: 0 }}>
      <defs>
        <radialGradient id="pg" cx="50%" cy="40%" r="55%">
          <stop offset="0%" stopColor="#2a5b48" />
          <stop offset="60%" stopColor="#143226" />
          <stop offset="100%" stopColor="#0C211A" />
        </radialGradient>
        <pattern id="dots" width="6" height="6" patternUnits="userSpaceOnUse">
          <circle cx="3" cy="3" r="0.7" fill="#000" opacity="0.3" />
        </pattern>
      </defs>
      <ellipse cx="180" cy="135" rx="115" ry="95" fill="url(#pg)" />
      <ellipse cx="180" cy="135" rx="115" ry="95" fill="url(#dots)" />
      <rect x="172" y="220" width="16" height="60" rx="4" fill="#0d1f17" />
      <rect x="160" y="225" width="40" height="14" rx="3" fill="#7a5a3a" />
    </svg>
  );
}

// ─── TRAIN ────────────────────────────────────────────
const DRILLS = {
  attacker: { title: '15 MIN POWER TOP-SPIN DRILL', intensity: 'HIGH', total: '15:00 TOTAL', steps: [
    { t: 'WARM-UP: SHADOW STROKES', d: '3 minutes of full-range motion without ball contact to align shoulder rotation.' },
    { t: 'RHYTHMIC REPETITION', d: '8 minutes: Forehand top-spin against backspin feed. Focus on contact point.' },
    { t: 'DYNAMIC TRANSITION', d: '4 minutes: Alternating backhand block and forehand power loop from mid-distance.' },
  ]},
  defender: { title: '18 MIN BLOCK & COUNTER DRILL', intensity: 'MEDIUM', total: '18:00 TOTAL', steps: [
    { t: 'CLOSE-TABLE STANCE', d: '4 minutes of low-bounce returns from feeder. Stay compact and reactive.' },
    { t: 'CHOP REPETITION',    d: '8 minutes: Long backhand chop with consistent depth and underspin.' },
    { t: 'COUNTER-LOOP STEP',  d: '6 minutes: Switch from defense to mid-distance counter-loop on cue.' },
  ]},
  blocker:  { title: '12 MIN PUNCH-BLOCK DRILL', intensity: 'MEDIUM', total: '12:00 TOTAL', steps: [
    { t: 'PADDLE SET-UP',   d: '3 minutes of half-volley positioning at the table edge.' },
    { t: 'BLOCK PLACEMENT', d: '6 minutes: Alternate cross-court and down-the-line blocks against top-spin feed.' },
    { t: 'PUNCH FINISH',    d: '3 minutes: Punch-block close to the net to end rallies fast.' },
  ]},
};

function TrainScreen() {
  const { showToast, openSheet } = useUI();
  const [style, setStyle] = useState('attacker');
  const [focus, setFocus] = useState('');
  const [generated, setGenerated] = useState('attacker');
  const [done, setDone] = useState({});
  const drill = DRILLS[generated];

  const toggleStep = (i) => setDone(d => ({ ...d, [`${generated}-${i}`]: !d[`${generated}-${i}`] }));
  const isDone = (i) => !!done[`${generated}-${i}`];

  return (
    <div style={{ padding: '4px 18px 130px', display: 'flex', flexDirection: 'column', gap: 18 }}>
      {/* Hero */}
      <div style={{
        position: 'relative', borderRadius: 22, overflow: 'hidden',
        border: `1px solid ${C.border}`, background: C.card,
        padding: '22px 22px 22px',
      }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center',
          padding: '7px 16px', borderRadius: 999,
          border: `1px solid ${C.borderHi}`,
          background: 'rgba(184,220,197,0.05)',
          color: C.mint,
          fontFamily: fontSans, fontWeight: 700, fontSize: 11, letterSpacing: '0.18em',
        }}>TRAINING MODULE</div>

        <div style={{
          fontFamily: fontDisplay, fontWeight: 800, fontSize: 64, lineHeight: 0.92,
          color: C.ink, letterSpacing: '0.005em', marginTop: 14,
        }}>IA DRILL<br/>MASTER</div>

        <div style={{
          color: C.inkDim, fontFamily: fontSans, fontSize: 14, lineHeight: 1.45,
          marginTop: 12, textWrap: 'pretty',
        }}>Precision-engineered drills tailored to your specific mechanical profile. Elevate your ELO through rhythmic repetition.</div>

        <div style={{
          marginTop: 18, height: 130, borderRadius: 14, overflow: 'hidden',
          border: `1px solid ${C.border}`, position: 'relative',
        }}>
          <ArenaSVG />
        </div>
      </div>

      {/* Player style */}
      <Card style={{ padding: 20 }}>
        <div style={kicker}>01. PLAYER STYLE</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 14 }}>
          {['attacker','defender','blocker'].map(opt => (
            <label key={opt} onClick={() => setStyle(opt)} style={{
              display: 'flex', alignItems: 'center', gap: 14, padding: '10px 4px',
              cursor: 'pointer', color: C.ink,
              userSelect: 'none',
            }}>
              <span style={{
                width: 22, height: 22, borderRadius: 99,
                border: `1.5px solid ${style === opt ? C.mint : 'rgba(242,247,242,0.45)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {style === opt && <span style={{ width: 11, height: 11, background: C.mint, borderRadius: 99 }} />}
              </span>
              <span style={{ fontFamily: fontSans, fontWeight: 700, fontSize: 14, letterSpacing: '0.12em' }}>
                {opt.toUpperCase()}
              </span>
            </label>
          ))}
        </div>
      </Card>

      {/* Focus point */}
      <Card style={{ padding: 20 }}>
        <div style={kicker}>02. FOCUS POINT</div>
        <input
          value={focus} onChange={e => setFocus(e.target.value)}
          placeholder="e.g. Backhand Speed"
          style={{
            marginTop: 12, width: '100%', boxSizing: 'border-box',
            padding: '14px 16px', borderRadius: 12,
            background: 'rgba(8,22,17,0.55)',
            border: `1px solid ${C.border}`,
            color: C.ink, fontFamily: fontSans, fontSize: 14,
            outline: 'none',
          }}
        />
        <button onClick={() => { setGenerated(style); setDone({}); showToast(`Drill generated for ${style.toUpperCase()}${focus ? ' — focus: ' + focus : ''}`); }} style={{
          marginTop: 14, width: '100%', padding: '15px 20px', borderRadius: 12,
          background: C.mint, border: 'none', color: '#0C211A',
          fontFamily: fontSans, fontWeight: 700, fontSize: 13, letterSpacing: '0.18em',
          cursor: 'pointer',
          boxShadow: '0 6px 20px rgba(184,220,197,0.18)',
        }}>GENERATE DRILL</button>
      </Card>

      {/* Output */}
      <Card style={{ padding: 20 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={kicker}>RECOMMENDED OUTPUT</div>
          <div style={{ color: C.inkDim }}>{Icon.pin(16)}</div>
        </div>
        <div style={{
          marginTop: 6, fontFamily: fontDisplay, fontWeight: 800, fontSize: 19,
          color: C.ink, letterSpacing: '0.02em',
        }}>{drill.title}</div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 16 }}>
          {drill.steps.map((s, i) => {
            const d = isDone(i);
            return (
            <button key={i} onClick={() => toggleStep(i)} style={{
              all: 'unset', cursor: 'pointer',
              padding: '14px 16px', borderRadius: 14,
              background: d ? 'rgba(184,220,197,0.08)' : 'rgba(8,22,17,0.45)',
              border: `1px solid ${d ? C.borderHi : C.border}`,
              display: 'flex', gap: 14, alignItems: 'flex-start',
              transition: 'all .2s ease',
            }}>
              <div style={{
                fontFamily: fontDisplay, fontWeight: 800, fontSize: 22,
                color: d ? C.mint : C.mint, lineHeight: 1, minWidth: 26, letterSpacing: '0.02em',
                opacity: d ? 0.5 : 1,
              }}>{String(i+1).padStart(2,'0')}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: fontSans, fontWeight: 700, fontSize: 13.5, color: C.ink, letterSpacing: '0.08em', textDecoration: d ? 'line-through' : 'none', opacity: d ? 0.55 : 1 }}>{s.t}</div>
                <div style={{ marginTop: 6, fontFamily: fontSans, fontSize: 12.5, color: C.inkDim, lineHeight: 1.45 }}>{s.d}</div>
              </div>
              <div style={{
                width: 22, height: 22, borderRadius: 6, flexShrink: 0,
                border: `1.5px solid ${d ? C.mint : 'rgba(242,247,242,0.35)'}`,
                background: d ? C.mint : 'transparent',
                color: '#0C211A',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{d && Icon.check(14)}</div>
            </button>
            );
          })}
        </div>

        <div style={{ display: 'flex', gap: 8, marginTop: 16, flexWrap: 'wrap' }}>
          <Chip><span style={{ color: C.cream }}>{Icon.clock(13)}</span> {drill.total}</Chip>
          <Chip><span style={{ color: C.cream }}>{Icon.trend(13)}</span> INTENSITY: {drill.intensity}</Chip>
        </div>
      </Card>

      {/* Trajectory */}
      <div style={{
        position: 'relative', borderRadius: 22, overflow: 'hidden',
        border: `1px solid ${C.border}`, background: C.card,
      }}>
        <div style={{ height: 170, position: 'relative', overflow: 'hidden' }}>
          <TrajectorySVG />
        </div>
        <div style={{ padding: '4px 22px 22px' }}>
          <div style={{
            fontFamily: fontDisplay, fontWeight: 800, fontSize: 28, color: C.ink,
            letterSpacing: '0.01em',
          }}>TRAJECTORY ANALYSIS</div>
          <div style={{ color: C.inkDim, fontFamily: fontSans, fontSize: 13.5, lineHeight: 1.5, marginTop: 8, textWrap: 'pretty' }}>
            Our AI analyzes your impact angle to ensure maximum rotation. This specific drill increases your RPM by an average of 14%.
          </div>
          <button onClick={() => openSheet({ title: 'TRAJECTORY METRICS', body: <MetricsSheet /> })} style={{
            marginTop: 16, padding: '12px 20px', borderRadius: 12,
            background: 'transparent', border: `1px solid ${C.borderHi}`,
            color: C.cream, fontFamily: fontSans, fontWeight: 700, fontSize: 12,
            letterSpacing: '0.18em', cursor: 'pointer',
          }}>VIEW FULL METRICS</button>
        </div>
      </div>
    </div>
  );
}

function Chip({ children }) {
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      padding: '8px 14px', borderRadius: 999,
      background: 'rgba(8,22,17,0.45)',
      border: `1px solid ${C.border}`,
      fontFamily: fontSans, fontWeight: 600, fontSize: 11.5, letterSpacing: '0.12em',
      color: C.ink,
    }}>{children}</div>
  );
}

function ArenaSVG() {
  return (
    <svg width="100%" height="100%" viewBox="0 0 360 140" preserveAspectRatio="xMidYMid slice" style={{ display: 'block' }}>
      <defs>
        <linearGradient id="ar" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="#1d4636" />
          <stop offset="100%" stopColor="#0a1b14" />
        </linearGradient>
        <radialGradient id="lamp" cx="50%" cy="0%" r="60%">
          <stop offset="0%" stopColor="rgba(232,201,155,0.45)" />
          <stop offset="100%" stopColor="rgba(232,201,155,0)" />
        </radialGradient>
      </defs>
      <rect width="360" height="140" fill="url(#ar)" />
      <rect width="360" height="140" fill="url(#lamp)" />
      {/* table */}
      <g opacity="0.85">
        <polygon points="100,110 260,110 320,135 40,135" fill="#0e2d23" stroke="#3a6a55" strokeWidth="1"/>
        <line x1="180" y1="110" x2="180" y2="135" stroke="#3a6a55" strokeWidth="1"/>
        <line x1="80" y1="120" x2="280" y2="120" stroke="#3a6a55" strokeWidth="0.7" strokeDasharray="4 4"/>
        <rect x="170" y="100" width="20" height="10" fill="#3a6a55" opacity="0.4"/>
      </g>
      {/* lights */}
      <circle cx="60" cy="20" r="3" fill="#e8c99b" opacity="0.8"/>
      <circle cx="180" cy="14" r="3" fill="#e8c99b" opacity="0.9"/>
      <circle cx="300" cy="20" r="3" fill="#e8c99b" opacity="0.8"/>
    </svg>
  );
}

function TrajectorySVG() {
  return (
    <svg width="100%" height="100%" viewBox="0 0 360 170" preserveAspectRatio="xMidYMid slice" style={{ display: 'block' }}>
      <defs>
        <linearGradient id="tj" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="#1d4636" />
          <stop offset="100%" stopColor="#0a1b14" />
        </linearGradient>
        <linearGradient id="arc" x1="0" x2="1">
          <stop offset="0%" stopColor="#f6c562" />
          <stop offset="100%" stopColor="#e8c99b" />
        </linearGradient>
      </defs>
      <rect width="360" height="170" fill="url(#tj)" />
      {/* grid */}
      <g stroke="#2a5b48" strokeWidth="0.5" opacity="0.6">
        {Array.from({length:8}).map((_,i)=>(<line key={i} x1="0" y1={20*i+10} x2="360" y2={20*i+10}/>))}
        {Array.from({length:12}).map((_,i)=>(<line key={i} x1={30*i} y1="0" x2={30*i} y2="170"/>))}
      </g>
      {/* player silhouette */}
      <g fill="#0a1b14" stroke="#2a5b48" strokeWidth="1">
        <ellipse cx="130" cy="60" rx="9" ry="11"/>
        <path d="M120 70 L100 110 L110 130 L130 130 L145 95 L160 80 L150 70 Z"/>
        <path d="M145 95 L175 70 L180 78 L150 105 Z"/>
      </g>
      {/* arc */}
      <path d="M 100 140 Q 200 -20 320 130" fill="none" stroke="url(#arc)" strokeWidth="3.5" strokeLinecap="round" filter="drop-shadow(0 0 6px rgba(246,197,98,0.6))"/>
      <circle cx="320" cy="130" r="4" fill="#f6c562"/>
    </svg>
  );
}

function MetricsSheet() {
  const m = [
    ['Avg. impact angle', '38.4°'],
    ['RPM gain', '+14%'],
    ['Top spin consistency', '82%'],
    ['Reaction time', '0.31s'],
    ['Mid-distance accuracy', '76%'],
    ['Stamina index', 'A−'],
  ];
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 4 }}>
        {m.map(([k,v]) => (
          <div key={k} style={{
            padding: 14, borderRadius: 14,
            background: 'rgba(8,22,17,0.45)',
            border: `1px solid ${C.border}`,
          }}>
            <div style={{ ...kicker, fontSize: 10 }}>{k.toUpperCase()}</div>
            <div style={{ marginTop: 6, fontFamily: fontDisplay, fontWeight: 800, fontSize: 24, color: C.ink, letterSpacing: '0.02em' }}>{v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function FilterSheet() {
  const [active, setActive] = useState('All');
  const opts = ['All','Wins','Losses','This week','This month'];
  const { showToast, closeSheet } = useUI();
  return (
    <div>
      <div style={{ fontFamily: fontSans, fontSize: 13, color: C.inkDim, marginBottom: 14 }}>Filter your recent encounters.</div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {opts.map(o => (
          <button key={o} onClick={() => setActive(o)} style={{
            padding: '10px 16px', borderRadius: 999,
            background: active === o ? C.mint : 'transparent',
            color: active === o ? '#0C211A' : C.ink,
            border: `1px solid ${active === o ? C.mint : C.borderHi}`,
            fontFamily: fontSans, fontWeight: 700, fontSize: 12, letterSpacing: '0.10em',
            cursor: 'pointer',
          }}>{o.toUpperCase()}</button>
        ))}
      </div>
      <button onClick={() => { closeSheet(); showToast(`Filter applied: ${active}`); }}
        style={{ ...btnPrimary, marginTop: 20, width: '100%' }}>APPLY</button>
    </div>
  );
}

function MatchDetailSheet({ m }) {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 18 }}>
        <Avatar hue={m.hue} verified={m.verified} initials={m.name.split(' ')[0][0] + m.name.split(' ')[1][0]} />
        <div>
          <div style={{ fontFamily: fontSans, fontWeight: 700, fontSize: 16 }}>{m.name}</div>
          <div style={{ fontFamily: fontSans, fontSize: 12.5, color: C.inkDim }}>{m.when} • {m.where}</div>
        </div>
      </div>
      <div style={{
        textAlign: 'center', padding: '22px 0', borderRadius: 16,
        background: 'rgba(8,22,17,0.45)', border: `1px solid ${C.border}`,
      }}>
        <div style={{ fontFamily: fontDisplay, fontWeight: 800, fontSize: 56, color: C.ink, letterSpacing: '0.04em', lineHeight: 1 }}>{m.score}</div>
        <div style={{ marginTop: 10, fontFamily: fontSans, fontWeight: 700, fontSize: 12, letterSpacing: '0.14em', color: m.elo >= 0 ? C.mint : C.loss }}>
          {m.elo >= 0 ? '+' : '−'}{String(Math.abs(m.elo)).padStart(2,'0')} ELO
        </div>
      </div>
      <div style={{ marginTop: 18 }}>
        {[['Sets','11-9 / 8-11 / 11-7 / 11-6'],['Aces','4'],['Unforced errors','7'],['Longest rally','22 hits']].map(([k,v]) => (
          <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: `1px solid ${C.border}` }}>
            <span style={{ ...kicker }}>{k.toUpperCase()}</span>
            <span style={{ fontFamily: fontSans, fontSize: 14, color: C.ink, fontWeight: 600 }}>{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function RecordMatchSheet() {
  const [opp, setOpp] = useState('');
  const [score, setScore] = useState('11 - 0');
  const { showToast, closeSheet } = useUI();
  return (
    <div>
      <div style={{ ...kicker, marginBottom: 8 }}>OPPONENT</div>
      <input value={opp} onChange={e => setOpp(e.target.value)} placeholder="e.g. Marc-Andre"
        style={inputStyle} />
      <div style={{ ...kicker, marginTop: 16, marginBottom: 8 }}>SCORE</div>
      <input value={score} onChange={e => setScore(e.target.value)}
        style={inputStyle} />
      <div style={{ ...kicker, marginTop: 16, marginBottom: 8 }}>LOCATION</div>
      <input placeholder="e.g. Canal St-Martin" style={inputStyle} />
      <button onClick={() => { closeSheet(); showToast(`Match logged: ${opp || 'opponent'} ${score}`); }}
        style={{ ...btnPrimary, marginTop: 20, width: '100%' }}>SAVE MATCH</button>
    </div>
  );
}

const inputStyle = {
  width: '100%', boxSizing: 'border-box',
  padding: '13px 16px', borderRadius: 12,
  background: 'rgba(8,22,17,0.55)', border: `1px solid ${C.border}`,
  color: C.ink, fontFamily: fontSans, fontSize: 14, outline: 'none',
};

// ─── MATCHES ──────────────────────────────────────────
const MATCHES = [
  { id:'julien', name:'JULIEN B.',  when:'2 hours ago', where:'Canal St-Martin',     score:'11 : 09', elo:14,  verified:true,  hue:140 },
  { id:'marie',  name:'MARIE L.',   when:'Yesterday',   where:'Parc de la Villette', score:'11 : 05', elo:12,  verified:false, hue:0   },
  { id:'thomas', name:'THOMAS R.',  when:'3 days ago',  where:'Place de la Bastille',score:'08 : 11', elo:-8,  verified:false, hue:30  },
  { id:'clara',  name:'CLARA D.',   when:'Last Week',   where:'Luxembourg Gardens',  score:'11 : 02', elo:18,  verified:true,  hue:200 },
];

function MatchesScreen() {
  const { showToast, openSheet } = useUI();
  return (
    <div style={{ padding: '24px 18px 130px', display: 'flex', flexDirection: 'column', gap: 18, position: 'relative' }}>
      {/* Season Stats heading */}
      <div style={{
        fontFamily: fontDisplay, fontWeight: 800, fontSize: 28,
        color: C.cream, letterSpacing: '0.04em',
      }}>SEASON STATS</div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
        {[
          { v: '42',    l: 'TOTAL\nWINS',  msg: 'Total wins this season: 42 (best run +6)' },
          { v: '68%',   l: 'WIN RATE',     msg: 'Win rate: 68% over 62 games' },
          { v: '10.4',  l: 'AVG\nSCORE',   msg: 'Average score per set: 10.4' },
        ].map((s,i)=>(
          <button key={i} onClick={() => showToast(s.msg)} style={{
            all: 'unset', cursor: 'pointer',
            borderRadius: 18, padding: '18px 12px 16px',
            background: 'rgba(184,220,197,0.06)',
            border: `1px solid ${C.border}`,
            textAlign: 'center',
          }}>
            <div style={{ fontFamily: fontDisplay, fontWeight: 800, fontSize: 30, color: C.ink, letterSpacing: '0.02em', lineHeight: 1 }}>{s.v}</div>
            <div style={{ marginTop: 10, fontFamily: fontSans, fontWeight: 600, fontSize: 12, color: C.inkDim, letterSpacing: '0.12em', whiteSpace: 'pre-line', lineHeight: 1.25 }}>{s.l}</div>
          </button>
        ))}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 }}>
        <div style={{ fontFamily: fontDisplay, fontWeight: 800, fontSize: 21, color: C.ink, letterSpacing: '0.04em' }}>RECENT ENCOUNTERS</div>
        <button onClick={() => openSheet({ title: 'FILTER MATCHES', body: <FilterSheet /> })} style={{ ...iconBtn, color: C.cream }}>{Icon.filter(22)}</button>
      </div>

      <Card style={{ padding: 4 }}>
        {MATCHES.map((m, i) => (
          <button key={m.id} onClick={() => openSheet({ title: m.name, body: <MatchDetailSheet m={m} /> })}
            style={{
              all: 'unset', cursor: 'pointer', width: '100%', boxSizing: 'border-box',
              display: 'flex', alignItems: 'center', gap: 14, padding: '16px 14px',
              borderBottom: i < MATCHES.length-1 ? `1px solid ${C.border}` : 'none',
            }}>
            <Avatar hue={m.hue} verified={m.verified} initials={m.name.split(' ')[0][0] + m.name.split(' ')[1][0]} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: fontSans, fontWeight: 700, fontSize: 15, color: C.ink, letterSpacing: '0.04em' }}>{m.name}</div>
              <div style={{ marginTop: 3, fontFamily: fontSans, fontSize: 13, color: C.inkDim, lineHeight: 1.35 }}>
                {m.when} • {m.where}
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontFamily: fontDisplay, fontWeight: 800, fontSize: 18, color: C.ink, letterSpacing: '0.02em' }}>{m.score}</div>
              <div style={{
                marginTop: 4, fontFamily: fontSans, fontWeight: 600, fontSize: 11,
                color: m.elo >= 0 ? C.inkDim : C.loss,
                letterSpacing: '0.10em',
              }}>{m.elo >= 0 ? '+' : '−'}{String(Math.abs(m.elo)).padStart(2,'0')} ELO</div>
            </div>
          </button>
        ))}
      </Card>

      <button onClick={() => showToast('Loading full history…')} style={{
        marginTop: 4, padding: '18px 24px', borderRadius: 16,
        background: 'rgba(239,229,200,0.05)',
        border: `1px solid rgba(239,229,200,0.25)`,
        color: C.cream, fontFamily: fontSans, fontWeight: 700, fontSize: 13,
        letterSpacing: '0.18em', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14,
      }}>VIEW FULL HISTORY {Icon.arrowR(18)}</button>

      {/* FAB */}
      <button onClick={() => openSheet({ title: 'RECORD MATCH', body: <RecordMatchSheet /> })} style={{
        position: 'absolute', right: 18, bottom: 6,
        width: 60, height: 60, borderRadius: 99,
        background: C.cream, border: 'none', color: '#1A3A2E',
        cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: '0 12px 32px rgba(239,229,200,0.35), 0 4px 12px rgba(0,0,0,0.4)',
      }}>{Icon.plus(26)}</button>
    </div>
  );
}

function Avatar({ hue = 140, verified = false, initials = '' }) {
  return (
    <div style={{ position: 'relative', width: 52, height: 52 }}>
      <div style={{
        width: 52, height: 52, borderRadius: 99, overflow: 'hidden',
        background: `radial-gradient(60% 60% at 35% 30%, hsl(${hue} 45% 55%) 0%, hsl(${hue} 50% 22%) 60%, #0a1b14 100%)`,
        border: `1.5px solid ${C.borderHi}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <span style={{ fontFamily: fontDisplay, fontWeight: 800, fontSize: 20, color: 'rgba(255,255,255,0.92)', letterSpacing: '0.02em' }}>{initials}</span>
      </div>
      {verified && <div style={{
        position: 'absolute', bottom: -2, right: -2, color: C.mint,
        background: C.bg, borderRadius: 99, padding: 1,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>{Icon.verify(18)}</div>}
    </div>
  );
}

// ─── PLACEHOLDER screens ──────────────────────────────
function PlaceholderScreen({ title, blurb }) {
  return (
    <div style={{ padding: '60px 28px 140px', display: 'flex', flexDirection: 'column', gap: 18 }}>
      <div style={{ fontFamily: fontDisplay, fontWeight: 800, fontSize: 56, lineHeight: 0.95, color: C.ink, letterSpacing: '0.02em' }}>{title}</div>
      <div style={{ fontFamily: fontSans, fontSize: 14, color: C.inkDim, lineHeight: 1.5 }}>{blurb}</div>
      <Card>
        <div style={kicker}>COMING SOON</div>
        <div style={{ marginTop: 12, color: C.inkDim, fontFamily: fontSans, fontSize: 14, lineHeight: 1.5 }}>
          This module is part of the Ping Pang Paris ecosystem. Tap the bottom tabs to explore HOME, TRAIN and MATCHES.
        </div>
      </Card>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────
function App() {
  const [tab, setTab] = useState('home');
  const { isMobile } = useViewport();

  const screen = useMemo(() => {
    switch (tab) {
      case 'home':    return <HomeScreen onNav={setTab} />;
      case 'train':   return <TrainScreen />;
      case 'matches': return <MatchesScreen />;
      case 'finder':  return <PlaceholderScreen title="FINDER" blurb="Locate clubs, tables and rivals across Paris." />;
      case 'merch':   return <PlaceholderScreen title="MERCH" blurb="Paddles, rubbers, apparel — curated for the active player." />;
      default:        return <HomeScreen onNav={setTab} />;
    }
  }, [tab]);

  const inner = (
    <UIProvider isMobile={isMobile}>
      <div style={{
        position: 'relative', height: '100%', width: '100%',
        background: C.bgGrad, color: C.ink, overflow: 'hidden',
      }}>
        <div data-screen-label={labelFor(tab)} style={{
          position: 'absolute', inset: 0, overflowY: 'auto',
          paddingTop: isMobile ? 0 : 44,
        }}>
          <TopBar />
          {screen}
        </div>
        <BottomNav tab={tab} onTab={setTab} />
      </div>
    </UIProvider>
  );

  // Mobile/tablet: full-bleed. Desktop: iPhone frame.
  if (isMobile) {
    return (
      <div style={{
        position: 'fixed', inset: 0,
        background: C.bg,
        fontFamily: fontSans,
      }}>
        {inner}
      </div>
    );
  }

  return (
    <div style={{
      minHeight: '100vh', width: '100%',
      background: '#06120D',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '32px 16px',
      backgroundImage: 'radial-gradient(60% 50% at 50% 0%, rgba(184,220,197,0.04) 0%, rgba(0,0,0,0) 70%)',
    }}>
      <IOSDevice width={402} height={874} dark={true}>
        {inner}
      </IOSDevice>
    </div>
  );
}

function labelFor(t) {
  return { home:'01 Home', train:'02 Train', matches:'03 Matches', finder:'04 Finder', merch:'05 Merch' }[t] || t;
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
